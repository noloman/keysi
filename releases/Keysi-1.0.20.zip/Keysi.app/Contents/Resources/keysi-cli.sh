#!/bin/sh
#
# keysi — drive Keysi from a terminal or a script.
#
# Ships inside the app bundle at
# /Applications/Keysi.app/Contents/Resources/keysi-cli.sh, so it is always
# the version that matches the installed app. To put it on your PATH:
#
#   sudo ln -sf /Applications/Keysi.app/Contents/Resources/keysi-cli.sh \
#       /usr/local/bin/keysi
#
# Every command is a `keysi://` URL, which is the whole design: this script
# holds no logic of its own, so it cannot drift from the app, and it can do
# nothing a `open keysi://…` could not already do by hand. The commands need
# Keysi Pro (they are part of the integrations tier); the app says so itself
# rather than this script guessing at your licence.
#
# POSIX sh on purpose — no bashisms, so it runs under /bin/sh on any macOS.

set -eu

usage() {
    cat <<'USAGE'
Usage: keysi <command> [argument]

  show [query]     Show the shortcuts panel for the app you were last in,
                   optionally with the search field pre-filled.
  practice         Open Practice Mode.
  progress         Open your progress summary.
  integrations     Show every way Keysi can be reached from outside itself.
  export [app]     Export an app's shortcuts (opens a save panel).
  license [key]    Activate a licence key, or open Settings ▸ Keysi Pro.
  help             This text.

Examples:
  keysi show save
  keysi export Figma
  keysi practice
USAGE
}

# `open` handles percent-encoding poorly for spaces and & in a query, so
# encode the argument here rather than hoping. Uses the shell and `od` only;
# no python, no perl, nothing that might not be installed.
urlencode() {
    LC_ALL=C awk 'BEGIN {
        for (i = 0; i < 256; i++) ord[sprintf("%c", i)] = i
        s = ARGV[1]
        out = ""
        for (i = 1; i <= length(s); i++) {
            c = substr(s, i, 1)
            if (c ~ /[A-Za-z0-9._~-]/) {
                out = out c
            } else {
                out = out sprintf("%%%02X", ord[c])
            }
        }
        print out
        # exit matters: without it awk goes on to treat the argument as a
        # filename once BEGIN ends, and fails because no such file exists.
        exit
    }' "$1"
}

open_url() {
    # -g: do not bring Keysi to the front. Keysi is a menu-bar agent and
    # decides for itself which of its windows should activate; stealing focus
    # from the terminal you just typed in is never what you wanted.
    open -g "$1"
}

command=${1:-help}
argument=${2:-}

case "$command" in
    show)
        if [ -n "$argument" ]; then
            open_url "keysi://show?q=$(urlencode "$argument")"
        else
            open_url "keysi://show"
        fi
        ;;
    practice)
        open_url "keysi://practice"
        ;;
    progress)
        open_url "keysi://progress"
        ;;
    integrations)
        open_url "keysi://integrations"
        ;;
    export)
        if [ -n "$argument" ]; then
            open_url "keysi://export?app=$(urlencode "$argument")"
        else
            open_url "keysi://export"
        fi
        ;;
    license)
        if [ -n "$argument" ]; then
            open_url "keysi://license?key=$(urlencode "$argument")"
        else
            open_url "keysi://license"
        fi
        ;;
    help | -h | --help)
        usage
        ;;
    *)
        printf 'keysi: unknown command "%s"\n\n' "$command" >&2
        usage >&2
        exit 64  # EX_USAGE
        ;;
esac
